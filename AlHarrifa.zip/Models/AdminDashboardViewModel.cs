namespace AlHarrifa.Models
{
    public class AdminDashboardViewModel
    {
        public List<User> Users { get; set; }
        public List<Product> Products { get; set; }
        public List<Order> Orders { get; set; }
    }
} 