// Product data is now in products.js

// Fetch top products from the API
async function fetchTopProducts() {
    try {
        const response = await fetch('/api/products/top');
        if (!response.ok) throw new Error('Failed to fetch products');
        return await response.json();
    } catch (error) {
        console.error('Error fetching products:', error);
        showNotification('Failed to load products. Please try again later.');
        return {};
    }
}

async function renderProducts() {
    // Show loading state
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        const itemsContainer = section.querySelector('.items');
        if (itemsContainer) {
            itemsContainer.innerHTML = '<div class="loading">Loading products...</div>';
        }
    });
    
    // Fetch products from API
    const productsByCategory = await fetchTopProducts();
    
    // Render products for each category
    Object.entries(productsByCategory).forEach(([category, products]) => {
        const section = document.getElementById(category.toLowerCase().replace(/\s+/g, '-'));
        if (!section) return;

        const itemsContainer = section.querySelector('.items');
        if (!itemsContainer) return;

        itemsContainer.innerHTML = '';
        
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'item';
            productCard.dataset.category = category;
            productCard.dataset.id = product.id;
            productCard.innerHTML = `
                <img src="${product.imageUrl}" alt="${product.name}">
                <div class="info">
                    <h3>${product.name}</h3>
                    <p>Price: $${product.price.toFixed(2)}</p>
                    <div class="product-controls">
                        <div class="quantity-selector">
                            <label>Qty:</label>
                            <input type="number" class="quantity-input" min="1" value="1">
                        </div>
                        <div class="product-buttons">
                            <button onclick="addToCart('${category}', ${product.id})">Add to Cart</button>
                            <button onclick="buyNow('${category}', ${product.id})">Buy Now</button>
                        </div>
                    </div>
                </div>
            `;
            itemsContainer.appendChild(productCard);
        });
    });
}

function addToCart(category, productId) {
    // Get product from the displayed products
    const productCard = document.querySelector(`[data-category="${category}"][data-id="${productId}"]`);
    if (!productCard) return;

    const product = {
        id: productId,
        name: productCard.querySelector('h3').textContent,
        price: parseFloat(productCard.querySelector('.price').textContent.replace('$', '')),
        category: category,
        imageUrl: productCard.querySelector('img').src
    };

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
    showNotification('Product added to cart!');
}

function buyNow(category, productId) {
    addToCart(category, productId);
    window.location.href = 'electronicpayment.html';
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    if (!cartItems || !cartTotal) return;

    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cartItems.innerHTML = '';
    
    let total = 0;
    cart.forEach((item, index) => {
        total += item.price;
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <span>${item.name}</span>
            <span>$${item.price.toFixed(2)}</span>
            <button onclick="removeFromCart(${index})">×</button>
        `;
        cartItems.appendChild(cartItem);
    });
    
    cartTotal.textContent = `$${total.toFixed(2)}`;
}

function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
}

function clearCart() {
    localStorage.removeItem('cart');
    updateCart();
}

function proceedToPayment() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length === 0) {
        showNotification('Your cart is empty!');
        return;
    }
    window.location.href = 'electronicpayment.html';
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    renderProducts();
    updateCart();
});
